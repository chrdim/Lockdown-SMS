package com.unipi.xdimtsasp17027.supermaketapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

public class InsertProducts extends AppCompatActivity  {

    Spinner productCategories,subCategories;

    EditText productNameEditText,productPriceEditText,productQuantityEditText;

    Uri imageUri;

    ImageView productImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_products);
        imageUri=null;

        productImageView=findViewById(R.id.imageView1333);

        productNameEditText=findViewById(R.id.editText502);
        productPriceEditText=findViewById(R.id.editText503);
        productQuantityEditText=findViewById(R.id.editText504);

        productCategories=findViewById(R.id.spinner2);
        subCategories=findViewById(R.id.spinner4);

        String[] items = new String[]{"Φρούτα", "Λαχανικά", "Κρεατικά","Είδη Αρτοζαχαροπλαστείου","Γαλακτοκομικά","Κάβα","Απορρυπαντικά και είδη καθαρισμού","Τροφές και έιδη κατοικιδίων","Τρόφιμα παντοπωλείου","Είδη προσωπικής υγιεινής","Ξηροί καρποί και σνακ","Αναψυκτικά και Νερά"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);

        productCategories.setAdapter(adapter);


        productCategories.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                if(productCategories.getSelectedItem().toString().equals("Φρούτα")){
                    String[] subCategoriesItems = new String[]{"Αποξηραμένα φρόυτα", "Φρέσκα φρούτα"};
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getApplication(), android.R.layout.simple_spinner_dropdown_item, subCategoriesItems);
                    subCategories.setAdapter(adapter2);

                }else if(productCategories.getSelectedItem().toString().equals("Λαχανικά")){

                    String[] subCategoriesItems = new String[]{"Φρέσκα λαχανικά", "Κατεψυγμένα λαχανικά","Έτοιμες σαλάτες"};
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getApplication(), android.R.layout.simple_spinner_dropdown_item, subCategoriesItems);
                    subCategories.setAdapter(adapter2);

                }else if(productCategories.getSelectedItem().toString().equals("Κρεατικά")){

                    String[] subCategoriesItems = new String[]{"Φρέσκα κρέατα", "Κατεψυγμένα κρέατα","Αλλαντικά"};
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getApplication(), android.R.layout.simple_spinner_dropdown_item, subCategoriesItems);
                    subCategories.setAdapter(adapter2);

                }else if(productCategories.getSelectedItem().toString().equals("Είδη Αρτοζαχαροπλαστείου")){

                    String[] subCategoriesItems = new String[]{"Γλυκά", "Ψωμί και αρτοπαρασκευάσματα","Πίτες και τορτίγιες"};
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getApplication(), android.R.layout.simple_spinner_dropdown_item, subCategoriesItems);
                    subCategories.setAdapter(adapter2);

                }else if(productCategories.getSelectedItem().toString().equals("Γαλακτοκομικά")){

                    String[] subCategoriesItems = new String[]{"Γάλατα", "Τυροκομικά","Γιαούρτια"};
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getApplication(), android.R.layout.simple_spinner_dropdown_item, subCategoriesItems);
                    subCategories.setAdapter(adapter2);

                }else if(productCategories.getSelectedItem().toString().equals("Κάβα")){

                    String[] subCategoriesItems = new String[]{"Κρασιά", "Ποτά","Μπύρες"};
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getApplication(), android.R.layout.simple_spinner_dropdown_item, subCategoriesItems);
                    subCategories.setAdapter(adapter2);

                }else if(productCategories.getSelectedItem().toString().equals("Απορρυπαντικά και είδη καθαρισμού")){

                    String[] subCategoriesItems = new String[]{"Καθαριστικά Γενικής Χρήσης", "Απορρυπαντικά"};
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getApplication(), android.R.layout.simple_spinner_dropdown_item, subCategoriesItems);
                    subCategories.setAdapter(adapter2);

                }else if(productCategories.getSelectedItem().toString().equals("Τροφές και έιδη κατοικιδίων")){

                    String[] subCategoriesItems = new String[]{"Τροφές και είδη για γάτες", "Τροφές και είδη για σκύλους","Τροφές και είδη για ψάρια,πτηνά κ.α"};
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getApplication(), android.R.layout.simple_spinner_dropdown_item, subCategoriesItems);
                    subCategories.setAdapter(adapter2);

                }else if(productCategories.getSelectedItem().toString().equals("Τρόφιμα παντοπωλείου")){

                    String[] subCategoriesItems = new String[]{"Μπαχαρικά", "Κονσέρβες","Όσπρια","Αυγά","Λάδια","Ρύζια"};
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getApplication(), android.R.layout.simple_spinner_dropdown_item, subCategoriesItems);
                    subCategories.setAdapter(adapter2);

                }else if(productCategories.getSelectedItem().toString().equals("Είδη προσωπικής υγιεινής")){

                    String[] subCategoriesItems = new String[]{"Είδη φαρμακείου", "Περιποίηση σώματος","Περιποίηση μαλλιών","Στοματική υγιεινή","Είδη ξυρίσματος"};
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getApplication(), android.R.layout.simple_spinner_dropdown_item, subCategoriesItems);
                    subCategories.setAdapter(adapter2);

                }else if(productCategories.getSelectedItem().toString().equals("Ξηροί καρποί και σνακ")){

                    String[] subCategoriesItems = new String[]{"Κράκερς", "Πατατάκια,γαριδάκια","Ξηροί καρποί"};
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getApplication(), android.R.layout.simple_spinner_dropdown_item, subCategoriesItems);
                    subCategories.setAdapter(adapter2);

                }else if(productCategories.getSelectedItem().toString().equals("Αναψυκτικά και Νερά")){

                    String[] subCategoriesItems = new String[]{"Χυμοί", "Αναψυκτικά,σόδες και ενεργειακά ποτά","Νερά"};
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getApplication(), android.R.layout.simple_spinner_dropdown_item, subCategoriesItems);
                    subCategories.setAdapter(adapter2);

                }







            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        });

    }

    public void uploadtoDatabase(View view){

        if(!(productNameEditText.getText().toString().equals("")||productQuantityEditText.getText().toString().equals("")||productPriceEditText.getText().toString().equals(""))){
            if(imageUri!=null){

                StorageReference storageReference= FirebaseStorage.getInstance().getReference().child("Products Images");
                StorageReference fileRef=storageReference.child(productNameEditText.getText().toString()+"image"+".jpg");

                fileRef.putFile(imageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        fileRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                            @Override
                            public void onSuccess(Uri uri) {


                                FirebaseDatabase.getInstance().getReference("Supermakets").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("products").child(productCategories.getSelectedItem().toString()).child(subCategories.getSelectedItem().toString()).child(productNameEditText.getText().toString()).child("Quantity").setValue(productQuantityEditText.getText().toString());
                                FirebaseDatabase.getInstance().getReference("Supermakets").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("products").child(productCategories.getSelectedItem().toString()).child(subCategories.getSelectedItem().toString()).child(productNameEditText.getText().toString()).child("Price").setValue(productPriceEditText.getText().toString());
                                FirebaseDatabase.getInstance().getReference("Supermakets").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("products").child(productCategories.getSelectedItem().toString()).child(subCategories.getSelectedItem().toString()).child(productNameEditText.getText().toString()).child("Image").setValue(uri.toString());
                                Toast.makeText(getApplicationContext(),"Το προϊόν σας καταχωρήθηκε επιτυχώς",Toast.LENGTH_SHORT).show();

                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_SHORT).show();
                            }
                        });

                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_SHORT).show();
                    }
                });
            }else{
                Toast.makeText(getApplicationContext(),"Για να συνεχίσετε θα πρέπει να εισάγετε μία εικόνα",Toast.LENGTH_SHORT).show();
            }
        }else{
            Toast.makeText(getApplicationContext(), "Για να συνεχίσετε θα πρέπει να συμπληρώσετε όλα τα πεδία", Toast.LENGTH_SHORT).show();
        }


    }

    public void chooseImage(View view){
        Intent pickPhoto = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(pickPhoto , 1);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==1){
            imageUri=data.getData();
            productImageView.setImageURI(imageUri);


        }
    }


    @Override
    public void onBackPressed() {

        new AlertDialog.Builder(this)
        .setMessage("Θέλετε σίγουρα να επιστέψετε πίσω")
        .setTitle("ΠΡΟΣΟΧΗ")
        .setCancelable(true)
        .setNegativeButton("Άκυρο", null)
        .setPositiveButton("Πίσω",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                        startActivity(new Intent(getApplicationContext(),AdminMainPage.class));

                    }
                }).create().show();


    }


}