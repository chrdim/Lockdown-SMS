package com.unipi.xdimtsasp17027.supermaketapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class WelcomePage extends AppCompatActivity {


    TextView textViewSignUp;
    EditText emailAddressEditText,passwordEditText;

    private FirebaseAuth mAuth;



    @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_welcome_page);

            textViewSignUp = findViewById(R.id.textView3);


            emailAddressEditText=findViewById(R.id.emailAddressEditText1);
            passwordEditText=findViewById(R.id.passEditText1);

            mAuth = FirebaseAuth.getInstance();

        }


        public void goToRegisterActivity(View view) {
            Intent intent = new Intent(this, Register.class);
            startActivity(intent);
        }

        public void login(View view){
            //έλεγχος για το αν είναι συμπληρωμένα όλα τα πεδία
            if(!(emailAddressEditText.getText().toString().equals("") || (passwordEditText.getText().toString()).equals(""))){

                //σύνδεση χρήστη με email και password
                mAuth.signInWithEmailAndPassword(emailAddressEditText.getText().toString(),passwordEditText.getText().toString())
                        .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if(task.isSuccessful()) {


                                    String[] words = mAuth.getCurrentUser().getDisplayName().split("--->");
                                    if(words[1].equals("admin")){
                                        startActivity(new Intent(getApplicationContext(),AdminMainPage.class));
                                    }else if(words[1].equals("customer")){



                                        startActivity(new Intent(getApplicationContext(),SelectAddressAcitvity.class));
                                   }





                                }
                                //έλεγχος για το αν το email είναι σε σωστή μορφή
                                else if(!(Patterns.EMAIL_ADDRESS.matcher(emailAddressEditText.getText().toString()).matches())){
                                    Toast.makeText(getApplicationContext(),"Η μορφή του email δεν είναι έγκυρη",Toast.LENGTH_SHORT).show();
                                }
                                //έλεγχος για το αν υπάρχει χρήστης με τα στοιχεία που εισήχθησαν
                                else{
                                    Toast.makeText(getApplicationContext(),"Τα παραπάνω στοιχεία δεν αντιστοιχούν σε κάποιον χρήστη.",Toast.LENGTH_SHORT).show();

                                }
                            }
                        });
            }else{
                Toast.makeText(getApplicationContext(),"Θα πρέπει να συμπληρωθούν όλα τα πεδία.",Toast.LENGTH_SHORT).show();

            }

        }



    public void onBackPressed() {

        new AlertDialog.Builder(this)
                .setMessage("Έξοδος από την εφαρμογή;")
                .setTitle("ΠΡΟΣΟΧΗ")
                .setCancelable(true)
                .setNegativeButton("Άκυρο", null)
                .setPositiveButton("Έξοδος",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                finishAffinity();


                            }
                        }).create().show();


    }
}
