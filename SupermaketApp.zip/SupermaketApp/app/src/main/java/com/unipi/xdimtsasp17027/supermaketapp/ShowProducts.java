package com.unipi.xdimtsasp17027.supermaketapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ShowProducts extends AppCompatActivity {

    Spinner productCategories,subCategories;
    ArrayList<View> viewArrayList;

    LinearLayout layout;

    TextView productNameTextView;

    ImageView deleteImageView,editImageView;

    String mainCategory,subcategory;
    ArrayList<ImageView> deleteImageViews, editImageViews;
    ArrayList<String>productNames;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_products);

        deleteImageViews =new ArrayList<ImageView>();
        editImageViews =new ArrayList<ImageView>();
        productNames=new ArrayList<String>();

        productCategories=findViewById(R.id.spinner24);
        subCategories=findViewById(R.id.spinner14);

        String[] items = new String[]{"Φρούτα", "Λαχανικά", "Κρεατικά","Είδη Αρτοζαχαροπλαστείου","Γαλακτοκομικά","Κάβα","Απορρυπαντικά και είδη καθαρισμού","Τροφές και έιδη κατοικιδίων","Τρόφιμα παντοπωλείου","Είδη προσωπικής υγιεινής","Ξηροί καρποί και σνακ","Αναψυκτικά και Νερά"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);

        productCategories.setAdapter(adapter);


        productCategories.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                if (productCategories.getSelectedItem().toString().equals("Φρούτα")) {
                    String[] subCategoriesItems = new String[]{"Αποξηραμένα φρόυτα", "Φρέσκα φρούτα"};
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getApplication(), android.R.layout.simple_spinner_dropdown_item, subCategoriesItems);
                    subCategories.setAdapter(adapter2);

                } else if (productCategories.getSelectedItem().toString().equals("Λαχανικά")) {

                    String[] subCategoriesItems = new String[]{"Φρέσκα λαχανικά", "Κατεψυγμένα λαχανικά", "Έτοιμες σαλάτες"};
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getApplication(), android.R.layout.simple_spinner_dropdown_item, subCategoriesItems);
                    subCategories.setAdapter(adapter2);

                } else if (productCategories.getSelectedItem().toString().equals("Κρεατικά")) {

                    String[] subCategoriesItems = new String[]{"Φρέσκα κρέατα", "Κατεψυγμένα κρέατα", "Αλλαντικά"};
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getApplication(), android.R.layout.simple_spinner_dropdown_item, subCategoriesItems);
                    subCategories.setAdapter(adapter2);

                } else if (productCategories.getSelectedItem().toString().equals("Είδη Αρτοζαχαροπλαστείου")) {

                    String[] subCategoriesItems = new String[]{"Γλυκά", "Ψωμί και αρτοπαρασκευάσματα", "Πίτες και τορτίγιες"};
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getApplication(), android.R.layout.simple_spinner_dropdown_item, subCategoriesItems);
                    subCategories.setAdapter(adapter2);

                } else if (productCategories.getSelectedItem().toString().equals("Γαλακτοκομικά")) {

                    String[] subCategoriesItems = new String[]{"Γάλατα", "Τυροκομικά", "Γιαούρτια"};
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getApplication(), android.R.layout.simple_spinner_dropdown_item, subCategoriesItems);
                    subCategories.setAdapter(adapter2);

                } else if (productCategories.getSelectedItem().toString().equals("Κάβα")) {

                    String[] subCategoriesItems = new String[]{"Κρασιά", "Ποτά", "Μπύρες"};
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getApplication(), android.R.layout.simple_spinner_dropdown_item, subCategoriesItems);
                    subCategories.setAdapter(adapter2);

                } else if (productCategories.getSelectedItem().toString().equals("Απορρυπαντικά και είδη καθαρισμού")) {

                    String[] subCategoriesItems = new String[]{"Καθαριστικά Γενικής Χρήσης", "Απορρυπαντικά"};
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getApplication(), android.R.layout.simple_spinner_dropdown_item, subCategoriesItems);
                    subCategories.setAdapter(adapter2);

                } else if (productCategories.getSelectedItem().toString().equals("Τροφές και έιδη κατοικιδίων")) {

                    String[] subCategoriesItems = new String[]{"Τροφές και είδη για γάτες", "Τροφές και είδη για σκύλους", "Τροφές και είδη για ψάρια,πτηνά κ.α"};
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getApplication(), android.R.layout.simple_spinner_dropdown_item, subCategoriesItems);
                    subCategories.setAdapter(adapter2);

                } else if (productCategories.getSelectedItem().toString().equals("Τρόφιμα παντοπωλείου")) {

                    String[] subCategoriesItems = new String[]{"Μπαχαρικά", "Κονσέρβες", "Όσπρια", "Αυγά", "Λάδια", "Ρύζια"};
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getApplication(), android.R.layout.simple_spinner_dropdown_item, subCategoriesItems);
                    subCategories.setAdapter(adapter2);

                } else if (productCategories.getSelectedItem().toString().equals("Είδη προσωπικής υγιεινής")) {

                    String[] subCategoriesItems = new String[]{"Είδη φαρμακείου", "Περιποίηση σώματος", "Περιποίηση μαλλιών", "Στοματική υγιεινή", "Είδη ξυρίσματος"};
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getApplication(), android.R.layout.simple_spinner_dropdown_item, subCategoriesItems);
                    subCategories.setAdapter(adapter2);

                } else if (productCategories.getSelectedItem().toString().equals("Ξηροί καρποί και σνακ")) {

                    String[] subCategoriesItems = new String[]{"Κράκερς", "Πατατάκια,γαριδάκια", "Ξηροί καρποί"};
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getApplication(), android.R.layout.simple_spinner_dropdown_item, subCategoriesItems);
                    subCategories.setAdapter(adapter2);

                } else if (productCategories.getSelectedItem().toString().equals("Αναψυκτικά και Νερά")) {

                    String[] subCategoriesItems = new String[]{"Χυμοί", "Αναψυκτικά,σόδες και ενεργειακά ποτά", "Νερά"};
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getApplication(), android.R.layout.simple_spinner_dropdown_item, subCategoriesItems);
                    subCategories.setAdapter(adapter2);

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    public void search(View view) {

        String category =productCategories.getSelectedItem().toString();
        String subCategory=subCategories.getSelectedItem().toString();

        viewArrayList = new ArrayList<View>();
        layout = findViewById(R.id.linearLayout222);


        mainCategory=category;
        subcategory=subCategory;

        layout.removeAllViewsInLayout();
        viewArrayList.clear();

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Supermakets").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("products").child(category).child(subCategory);

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {


                for (DataSnapshot datas : snapshot.getChildren()) {


                    View v = getLayoutInflater().inflate(R.layout.product_row, null, false);

                    productNameTextView=(TextView) v.findViewById(R.id.textView800);

                    deleteImageView=(ImageView)v.findViewById(R.id.imageView207);
                    editImageView=(ImageView) v.findViewById(R.id.imageView203);

                    deleteImageViews.add(deleteImageView);
                    editImageViews.add(editImageView);

                    productNameTextView.setText(datas.getKey());

                    productNames.add(datas.getKey());


                    viewArrayList.add(v);


                }

                if(viewArrayList.size()>0){
                    for (int i = 0; i < viewArrayList.size(); i++) {
                        if(viewArrayList.get(i).getParent() != null) {
                            ((ViewGroup)viewArrayList.get(i).getParent()).removeView(viewArrayList.get(i));
                        }
                        layout.addView(viewArrayList.get(i));
                        String productName=productNames.get(i);
                        editImageViews.get(i).setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                startActivity(new Intent(getApplicationContext(),EditProductActivity.class).putExtra("productName",productName)
                                .putExtra("mainCategory",mainCategory).putExtra("subCategory",subcategory));
                            }
                        });

                        deleteImageViews.get(i).setOnClickListener(new View.OnClickListener() {

                            @Override
                            public void onClick(View v) {

                                AlertDialog.Builder alert=new AlertDialog.Builder(getApplicationContext());
                                        alert.setMessage("Είστε σίγουροι ότι θέλετε να διαγράψετε το προϊόν "+productName);
                                        alert.setTitle("Προσοχή");
                                        alert.setCancelable(true);
                                        alert.setNegativeButton("Άκυρο", null);
                                        alert.setPositiveButton("Διαγραφή",
                                                new DialogInterface.OnClickListener() {
                                                    public void onClick(DialogInterface dialog, int which) {

                                                        layout.removeAllViewsInLayout();
                                                        viewArrayList.clear();

                                                        FirebaseDatabase database = FirebaseDatabase.getInstance();
                                                        DatabaseReference myRef = database.getReference("Supermakets").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("products").child(category).child(subCategory).child(productName);
                                                        myRef.removeValue();
                                                        Toast.makeText(getApplicationContext(),"To προϊόν "+productName+" διαγράφηκε επιτυχώς",Toast.LENGTH_SHORT).show();

                                                   }
                                                }).create();
                                        alert.show();
                            }

                        });

                    }
                }else{
                    Toast.makeText(getApplicationContext(), "Δεν έχετε καταχωρήσει κάποιο προϊόν μέχρι στιγμής", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

    @Override
    public void onBackPressed() {

        new AlertDialog.Builder(this)
                .setMessage("Θέλετε σίγουρα να επιστέψετε πίσω")
                .setTitle("ΠΡΟΣΟΧΗ")
                .setCancelable(true)
                .setNegativeButton("Άκυρο", null)
                .setPositiveButton("Πίσω",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                                startActivity(new Intent(getApplicationContext(),AdminMainPage.class));
                            }
                        }).create().show();

    }

}
