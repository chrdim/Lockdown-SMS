package com.unipi.xdimtsasp17027.supermaketapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterCustomerEmailNamePhone extends AppCompatActivity {

    EditText emailAddressEditText,usernameEditText,phoneEditText;
    SharedPreferences preferences;
    Button continueButton;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_customer_email_name_phone);

        emailAddressEditText=findViewById(R.id.emailAddressEditText2);
        usernameEditText=findViewById(R.id.usernameEditText);

        preferences= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        continueButton=findViewById(R.id.continueButton);

        phoneEditText=findViewById(R.id.editTextPhone);

        editor=preferences.edit();
    }

    public void saveEmailName(View view){
        if(!(emailAddressEditText.getText().toString().equals("")||usernameEditText.getText().toString().equals("")||phoneEditText.getText().toString().equals(""))){
            if(Patterns.EMAIL_ADDRESS.matcher(emailAddressEditText.getText().toString()).matches()){
                editor.putString("email",emailAddressEditText.getText().toString());
                editor.putString("username",usernameEditText.getText().toString());
                editor.putString("phone",phoneEditText.getText().toString());
                editor.apply();
                startActivity(new Intent(this, RegisterPassword.class));
            }else
                Toast.makeText(getApplicationContext(),"Η μορφή του email δεν είναι συμβατή",Toast.LENGTH_SHORT).show();
        }else
            Toast.makeText(getApplicationContext(),"Θα πρέπει να συμπληρωθούν όλα τα πεδία",Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBackPressed() {




        if(usernameEditText.getText().toString().equals("")&&emailAddressEditText.getText().toString().equals("")){
            finish();
            startActivity(new Intent(getApplicationContext(),Register.class));
        }else{
            new AlertDialog.Builder(this)
                    .setMessage("Τα δεδομένα που συμπληρώσατε θα χαθούν")
                    .setTitle("ΠΡΟΣΟΧΗ")
                    .setCancelable(true)
                    .setNegativeButton("Άκυρο", null)
                    .setPositiveButton("Πίσω",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    finish();
                                    startActivity(new Intent(getApplicationContext(),Register.class));


                                }
                            }).create().show();
        }



    }


}