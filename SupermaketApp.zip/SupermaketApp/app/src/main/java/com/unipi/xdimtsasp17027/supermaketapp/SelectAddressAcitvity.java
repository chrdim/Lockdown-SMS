package com.unipi.xdimtsasp17027.supermaketapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class SelectAddressAcitvity extends AppCompatActivity {


    ScrollView scrollView;
    Button addressButton;

    ImageView addImageView;
    TextView addTextView;

    TextView addressTextView;

    ArrayList<View> viewArrayList;

    ArrayList<String> addressArrayList;

    LinearLayout layout;

    String currentAddress;
    int counter;

    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_address_acitvity);

        counter=0;
        scrollView=findViewById(R.id.scrollView6);
        scrollView.setVisibility(View.INVISIBLE);

        preferences= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        editor=preferences.edit();


        addressArrayList=new ArrayList<String>();
        addImageView=findViewById(R.id.imageView505);
        addTextView=findViewById(R.id.textView17777);
        addImageView.setVisibility(View.INVISIBLE);
        addTextView.setVisibility(View.INVISIBLE);
        addressButton=findViewById(R.id.button189);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Customers").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("address");

        layout = findViewById(R.id.linearLayout6);
        viewArrayList = new ArrayList<View>();



        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {


                for (DataSnapshot datas : snapshot.getChildren()) {


                    View v = getLayoutInflater().inflate(R.layout.address_row, null, false);

                    addressTextView=(TextView)v.findViewById(R.id.textView9089);

                    currentAddress =datas.getValue(String.class);

                    addressArrayList.add(currentAddress);

                    addressTextView.setText(currentAddress);


                   viewArrayList.add(v);

                }


                if(viewArrayList.size()>0){
                    addressButton.setText(currentAddress);
                    for (int i = 0; i < viewArrayList.size(); i++) {
                        layout.addView(viewArrayList.get(i));
                        String address=addressArrayList.get(i);
                        viewArrayList.get(i).setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                addressButton.setText(address);
                            }
                        });

                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

    public void selectAddress(View view){

        counter++;
        if(counter%2==0){
            addressButton.setCompoundDrawablesWithIntrinsicBounds(0,0, R.drawable.arrowdown, 0);
            scrollView.setVisibility(View.INVISIBLE);

            addImageView.setVisibility(View.INVISIBLE);
            addTextView.setVisibility(View.INVISIBLE);

        }else{
            addressButton.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.arrowup, 0);
            scrollView.setVisibility(View.VISIBLE);

            addImageView.setVisibility(View.VISIBLE);
            addTextView.setVisibility(View.VISIBLE);
        }


    }

    public void goToNextActivity(View view){
        if(!(preferences.getString("customeraddress","").equals(""))){
            editor.putString("customeraddress",addressButton.getText().toString());
            editor.apply();
            startActivity(new Intent(this,CustomerSupermarketSelectionActivity.class));
        }else{
            Toast.makeText(getApplicationContext(), "Παρακαλώ εισάγετε διεύθυνση", Toast.LENGTH_SHORT).show();
        }

    }


    public void addAddress(View view){

        startActivity(new Intent(this,AddAddressActivity.class));
    }

    @Override
    public void onBackPressed() {



        new AlertDialog.Builder(this)
                .setMessage("Έξοδος από την εφαρμογή;")
                .setTitle("ΠΡΟΣΟΧΗ")
                .setCancelable(true)
                .setNegativeButton("Άκυρο", null)
                .setPositiveButton("Έξοδος",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                finishAffinity();


                            }
                        }).create().show();


    }
}