package com.unipi.xdimtsasp17027.supermaketapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.CursorTreeAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Callback;
import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.LogRecord;

public class CustomerSupermarketSelectionActivity extends AppCompatActivity {

    TextView welcomeTextView;
    private FirebaseAuth mAuth;

    ArrayList<View> viewArrayList;

    LinearLayout layout;

    TextView superMarketNameTextView,addressTextView;
    ImageView storeImageView,logoImageview;



    TextView textview;








    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_supermarket_selection);

        welcomeTextView=findViewById(R.id.textView71);

        mAuth = FirebaseAuth.getInstance();


        viewArrayList = new ArrayList<View>();





        textview=findViewById(R.id.textView71);

        layout = findViewById(R.id.linearLayout2);


        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Supermakets");






        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {


                for (DataSnapshot datas : snapshot.getChildren()) {



                    View v = getLayoutInflater().inflate(R.layout.supermaket_row, null, false);

                    String x = datas.child("location").child("latitude").getValue().toString();
                    String y = datas.child("location").child("longitude").getValue().toString();

                    String storeName = datas.child("name").getValue().toString();


                    storeImageView=(ImageView) v.findViewById(R.id.imageView70);

                    logoImageview=(ImageView) v.findViewById(R.id.imageView300);




                    superMarketNameTextView=(TextView) v.findViewById(R.id.textView72);
                    addressTextView=(TextView) v.findViewById(R.id.textView73);


                    addressTextView.setText(String.valueOf(x+y));


                    superMarketNameTextView.setText(storeName);







                    String imageUrl=datas.child("image").getValue().toString();
                    Picasso.get().load(Uri.parse(imageUrl)).into(storeImageView);

                    String logoUrl=datas.child("logo").getValue().toString();
                    Picasso.get().load(Uri.parse(logoUrl)).into(logoImageview);





                    viewArrayList.add(v);










                }







                for (int i = 0; i < viewArrayList.size(); i++) {
                    layout.addView(viewArrayList.get(i));
                }




            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });





    }





    @Override
    public void onBackPressed() {



        finish();
        startActivity(new Intent(this,SelectAddressAcitvity.class));


    }


}